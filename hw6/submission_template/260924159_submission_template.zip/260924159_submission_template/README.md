Hi, dear TA!
I also included a file "credential.json" which contains my client_id, client_secret, username and password. When I collected data, I retrieved them from my script.
If you are to run the "collect.py", you need to run with my credential file, or replace those fields if necessary, otherwise it will give fileNotFound error.
Thank you <3