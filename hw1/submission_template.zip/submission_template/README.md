There are some duplicated tweets in my newly annotated dataset. 
For example: line 11 and 12 (double counted tweets that did not mention Trump -> cause lower percentage)
Line 54 and 55 (the opposite)